from pyUltroid.functions.asst_fns import *

from .. import *

OWNER_NAME = ultroid_bot.me.first_name
OWNER_ID = ultroid_bot.me.id
